# Calculadora JS

<img src="https://i.ibb.co/QJBNx5v/Screen-Shot-2021-01-31-at-22-41-36.png" alt="drawing" width="400"/>

**Calculadora desarrollada en este tutorial:** https://youtu.be/7YDagj3cVAk

Tecnologías:
- HTML
- Css
- JavaScript
